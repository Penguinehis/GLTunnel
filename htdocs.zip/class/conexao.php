<?php
session_start();
$servidor = "localhost";
$usuario = "painelgl";
$senha = "SUASENHA";
$dbname = "painelgl";
$link2 = "SEUIP OU DOMINIO";
//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
//.

?>