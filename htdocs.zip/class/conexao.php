<?php
session_start();
$servidor = "localhost";
$usuario = "glmidia";
$senha = "8(-g";
$dbname = "glmidia";
$link2 = "conecta4.lmhostbr.shop";
//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
//.

?>